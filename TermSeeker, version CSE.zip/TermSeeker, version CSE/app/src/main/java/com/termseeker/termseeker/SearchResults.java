package com.termseeker.termseeker;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.*;
import android.webkit.WebView;

public class SearchResults extends AppCompatActivity {

    WebView webView;
    String toBeSearched;
    CharSequence keySum;
    String keySum2;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_search_results);
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        setSupportActionBar (toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        CharSequence fName = intent.getCharSequenceExtra("sending");
        CharSequence key = intent.getCharSequenceExtra("keywords");
        CharSequence key4 = intent.getCharSequenceExtra("keywords2");
        String keys1 = intent.getStringExtra ("lan1");
        String keys2 = intent.getStringExtra ("lan2");

        keySum =  new StringBuilder().append(key).append(key4);
        keySum2 = fName + "site=.ru";
        webView = (android.webkit.WebView) findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        toBeSearched = "https://cse.google.com/cse/publicurl?cx=012060000240980612434:ht9kaowpedm#gsc.tab=0&" +
                "gsc.sort=&gsc.q=" + keySum2 + "&gsc.ref=more%3A" + keySum;

        webView.loadUrl(toBeSearched);

    }

}


//toBeSearched = "https://cse.google.com/cse/publicurl?cx=012060000240980612434:ht9kaowpedm#gsc.tab=0&" +
//        "gsc.sort=&gsc.q=" + fName + "%20%22site%3D." + keys1 + "%22%20" + "OR" + "%20%22site%3D." + keys2 +
//        "%22%20" + "&gsc.ref=more%3A" + keySum;
