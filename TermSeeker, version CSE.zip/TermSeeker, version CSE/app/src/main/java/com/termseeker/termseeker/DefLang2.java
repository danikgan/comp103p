package com.termseeker.termseeker;

import java.util.HashMap;

public class DefLang2 {
    public HashMap<String, String> hashMethodDefLang2() {
        HashMap<String, String> n = new HashMap<String, String> ();

        n.put ("أفريكانية", "AF");
        n.put ("Afrikaans", "AF");
        n.put ("афрыкаанс", "AF");
        n.put ("африканс", "AF");
        n.put ("আফ্রিকান্স	", "AF");
        n.put ("Africaans", "AF");
        n.put ("Afrikánština", "AF");
        n.put ("Affricaneg", "AF");
        n.put ("Αφρικανικά", "AF");
        n.put ("Afrikaani", "AF");
        n.put ("آفریکانس", "AF");
        n.put ("अफ्रीकी", "AF");
        n.put ("Afrikanas", "AF");
        n.put ("אפריקאנס", "AF");
        n.put ("アフリカーンス語", "AF");
        n.put ("아프리카", "AF");
        n.put ("Africa", "AF");
        n.put ("Afrikansas", "AF");
        n.put ("Afrikāņu", "AF");
        n.put ("Afrikánčina", "AF");
        n.put ("Kiafrikaans", "AF");
        n.put ("ஆஃப்ரிகான்ஸ்", "AF");
        n.put ("ఆఫ్రికాన్స్", "AF");
        n.put ("อัฟริกัน", "AF");
        n.put ("Aprikaans", "AF");
        n.put ("Afrika Dilleri", "AF");
        n.put ("ایفریکانز", "AF");
        n.put ("אַפֿריקאַנס", "AF");
        n.put ("南非荷兰语", "AF");

        return n;
    }
}
