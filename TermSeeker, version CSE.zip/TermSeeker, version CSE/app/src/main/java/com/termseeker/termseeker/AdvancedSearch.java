package com.termseeker.termseeker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.text.TextUtils.getTrimmedLength;

public class AdvancedSearch extends AppCompatActivity{

    EditText adSearchIn1;
    EditText adSearchIn2;
    EditText adSearchIn3;
    EditText adSearchIn4;
    String newadSearchIn1;
    String newadSearchIn2;
    String newadSearchIn3;
    String newadSearchIn4;
    String queryToSend;
    String spinnerLang2 = null;
    String spinnerLanguage = null;
    String keywords = null;
    String keywords2 = null;
    SQLiteDatabase userHistoryDB = null;
    private static final int SEARCH_REQUEST = 1010;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //preventing auto-focus
        ScrollView view = (ScrollView)findViewById(R.id.scrollView1);
        view.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        view.setFocusable(true);
        view.setFocusableInTouchMode(true);
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.requestFocusFromTouch();
                return false;
            }
        });

        SharedPreferences pref1 = getApplicationContext().getSharedPreferences ("MyPref1", MODE_PRIVATE);
        SharedPreferences pref2 = getApplicationContext().getSharedPreferences ("MyPref2", MODE_PRIVATE);

        final int defaultValue1 = pref1.getInt ("spinner1", 0);
        final int defaultValue2 = pref2.getInt ("spinner2", 0);

        SharedPreferences pref3 = getApplicationContext().getSharedPreferences ("MyPref3", MODE_PRIVATE);
        SharedPreferences pref4 = getApplicationContext().getSharedPreferences ("MyPref4", MODE_PRIVATE);

        final boolean checked1 = pref3.getBoolean ("switch1", false);
        final boolean checked2 = pref4.getBoolean ("switch2", false);

        // spinner 1
        final Spinner staticSpinner1 = (Spinner) findViewById(R.id.spinner1);
        // Create an ArrayAdapter using the string array and a default spinner
        ArrayAdapter<CharSequence> staticAdapter1 = ArrayAdapter.createFromResource(this, R.array.lang,
                        android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        staticAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        staticSpinner1.setAdapter(staticAdapter1);
        if(checked1 == true){
            staticSpinner1.setSelection (defaultValue1 - 1);
        }

        // spinner 2
        final Spinner staticSpinner2 = (Spinner) findViewById(R.id.spinner2);

        //keywords spinner
        final Spinner staticSpinner3 = (Spinner) findViewById(R.id.spinner3);

        staticSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                spinnerLanguage = staticSpinner1.getSelectedItem().toString();

                switch (spinnerLanguage) {
                    case "Afrikaans":
                        ArrayAdapter<CharSequence> staticAdapterAF = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.af, android.R.layout.simple_spinner_item);
                        staticAdapterAF.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterAF);
                        ArrayAdapter<CharSequence> staticAdapterAFK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.afk, android.R.layout.simple_spinner_item);
                        staticAdapterAFK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterAFK);
                        break;
                    case "Arabic":
                        ArrayAdapter<CharSequence> staticAdapterAR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ar, android.R.layout.simple_spinner_item);
                        staticAdapterAR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterAR);
                        ArrayAdapter<CharSequence> staticAdapterARK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ark, android.R.layout.simple_spinner_item);
                        staticAdapterARK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterARK);
                        break;
                    case "Azerbaijani":
                        ArrayAdapter<CharSequence> staticAdapterAZ = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.az, android.R.layout.simple_spinner_item);
                        staticAdapterAZ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterAZ);
                        ArrayAdapter<CharSequence> staticAdapterAZK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.azk, android.R.layout.simple_spinner_item);
                        staticAdapterAZK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterAZK);
                        break;
                    case "Belarusian":
                        ArrayAdapter<CharSequence> staticAdapterBE = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.be, android.R.layout.simple_spinner_item);
                        staticAdapterBE.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterBE);
                        ArrayAdapter<CharSequence> staticAdapterBEK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.bek, android.R.layout.simple_spinner_item);
                        staticAdapterBEK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterBEK);
                        break;
                    case "Bulgarian":
                        ArrayAdapter<CharSequence> staticAdapterBG = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.bg, android.R.layout.simple_spinner_item);
                        staticAdapterBG.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterBG);
                        ArrayAdapter<CharSequence> staticAdapterBGK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.bgk, android.R.layout.simple_spinner_item);
                        staticAdapterBGK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterBGK);
                        break;
                    case "Bengali":
                        ArrayAdapter<CharSequence> staticAdapterBN = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.bn, android.R.layout.simple_spinner_item);
                        staticAdapterBN.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterBN);
                        ArrayAdapter<CharSequence> staticAdapterBNK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.bnk, android.R.layout.simple_spinner_item);
                        staticAdapterBNK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterBNK);
                        break;
                    case "Catalan":
                        ArrayAdapter<CharSequence> staticAdapterCA = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.ca, android.R.layout.simple_spinner_item);
                        staticAdapterCA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterCA);
                        ArrayAdapter<CharSequence> staticAdapterCAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.cak, android.R.layout.simple_spinner_item);
                        staticAdapterCAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterCAK);
                        break;
                    case "Czech":
                        ArrayAdapter<CharSequence> staticAdapterCS = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.cs, android.R.layout.simple_spinner_item);
                        staticAdapterCS.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterCS);
                        ArrayAdapter<CharSequence> staticAdapterCSK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.csk, android.R.layout.simple_spinner_item);
                        staticAdapterCSK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterCSK);
                        break;
                    case "Welsh":
                        ArrayAdapter<CharSequence> staticAdapterCY = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.cy, android.R.layout.simple_spinner_item);
                        staticAdapterCY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterCY);
                        ArrayAdapter<CharSequence> staticAdapterCYK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.cyk, android.R.layout.simple_spinner_item);
                        staticAdapterCYK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterCYK);
                        break;
                    case "Danish":
                        ArrayAdapter<CharSequence> staticAdapterDA = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.da, android.R.layout.simple_spinner_item);
                        staticAdapterDA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterDA);
                        ArrayAdapter<CharSequence> staticAdapterDAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.dak, android.R.layout.simple_spinner_item);
                        staticAdapterDAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterDAK);
                        break;
                    case "German":
                        ArrayAdapter<CharSequence> staticAdapterDE = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.de, android.R.layout.simple_spinner_item);
                        staticAdapterDE.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterDE);
                        ArrayAdapter<CharSequence> staticAdapterDEK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.dek, android.R.layout.simple_spinner_item);
                        staticAdapterDEK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterDEK);
                        break;
                    case "Greek":
                        ArrayAdapter<CharSequence> staticAdapterEL = ArrayAdapter.createFromResource(
                                getBaseContext(), R.array.el, android.R.layout.simple_spinner_item);
                        staticAdapterEL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterEL);
                        ArrayAdapter<CharSequence> staticAdapterELK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.elk, android.R.layout.simple_spinner_item);
                        staticAdapterELK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterELK);
                        break;
                    case "English":
                        ArrayAdapter<CharSequence> staticAdapterEN = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.en, android.R.layout.simple_spinner_item);
                        staticAdapterEN.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterEN);
                        ArrayAdapter<CharSequence> staticAdapterENK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.enk, android.R.layout.simple_spinner_item);
                        staticAdapterENK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterENK);
                        break;
                    case "Esperanto":
                        ArrayAdapter<CharSequence> staticAdapterEO = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.eo, android.R.layout.simple_spinner_item);
                        staticAdapterEO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterEO);
                        ArrayAdapter<CharSequence> staticAdapterEOK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.eok, android.R.layout.simple_spinner_item);
                        staticAdapterEOK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterEOK);
                        break;
                    case "Spanish":
                        ArrayAdapter<CharSequence> staticAdapterES = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.es, android.R.layout.simple_spinner_item);
                        staticAdapterES.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterES);
                        ArrayAdapter<CharSequence> staticAdapterESK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.esk, android.R.layout.simple_spinner_item);
                        staticAdapterESK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterESK);
                        break;
                    case "Estonian":
                        ArrayAdapter<CharSequence> staticAdapterET = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.et, android.R.layout.simple_spinner_item);
                        staticAdapterET.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterET);
                        ArrayAdapter<CharSequence> staticAdapterETK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.etk, android.R.layout.simple_spinner_item);
                        staticAdapterETK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterETK);
                        break;
                    case "Basque":
                        ArrayAdapter<CharSequence> staticAdapterEU = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.eu, android.R.layout.simple_spinner_item);
                        staticAdapterEU.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterEU);
                        ArrayAdapter<CharSequence> staticAdapterEUK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.euk, android.R.layout.simple_spinner_item);
                        staticAdapterEUK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterEUK);
                        break;
                    case "Persian":
                        ArrayAdapter<CharSequence> staticAdapterFA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.fa, android.R.layout.simple_spinner_item);
                        staticAdapterFA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterFA);
                        ArrayAdapter<CharSequence> staticAdapterFAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.fak, android.R.layout.simple_spinner_item);
                        staticAdapterFAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterFAK);
                        break;
                    case "Finnish":
                        ArrayAdapter<CharSequence> staticAdapterFI = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.fi, android.R.layout.simple_spinner_item);
                        staticAdapterFI.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterFI);
                        ArrayAdapter<CharSequence> staticAdapterFIK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.fik, android.R.layout.simple_spinner_item);
                        staticAdapterFIK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterFIK);
                        break;
                    case "French":
                        ArrayAdapter<CharSequence> staticAdapterFR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.fr, android.R.layout.simple_spinner_item);
                        staticAdapterFR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterFR);
                        ArrayAdapter<CharSequence> staticAdapterFRK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.frk, android.R.layout.simple_spinner_item);
                        staticAdapterFRK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterFRK);
                        break;
                    case "Irish":
                        ArrayAdapter<CharSequence> staticAdapterGA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ga, android.R.layout.simple_spinner_item);
                        staticAdapterGA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterGA);
                        ArrayAdapter<CharSequence> staticAdapterGAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.gak, android.R.layout.simple_spinner_item);
                        staticAdapterGAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterGAK);
                        break;
                    case "Galician":
                        ArrayAdapter<CharSequence> staticAdapterGL = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.gl, android.R.layout.simple_spinner_item);
                        staticAdapterGL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterGL);
                        ArrayAdapter<CharSequence> staticAdapterGLK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.glk, android.R.layout.simple_spinner_item);
                        staticAdapterGLK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterGLK);
                        break;
                    case "Hindi":
                        ArrayAdapter<CharSequence> staticAdapterHI = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hi, android.R.layout.simple_spinner_item);
                        staticAdapterHI.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterHI);
                        ArrayAdapter<CharSequence> staticAdapterHIK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hik, android.R.layout.simple_spinner_item);
                        staticAdapterHIK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterHIK);
                        break;
                    case "Croatian":
                        ArrayAdapter<CharSequence> staticAdapterHR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hr, android.R.layout.simple_spinner_item);
                        staticAdapterHR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterHR);
                        ArrayAdapter<CharSequence> staticAdapterHRK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hrk, android.R.layout.simple_spinner_item);
                        staticAdapterHRK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterHRK);
                        break;
                    case "Haitian Creole":
                        ArrayAdapter<CharSequence> staticAdapterHT = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ht, android.R.layout.simple_spinner_item);
                        staticAdapterHT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterHT);
                        ArrayAdapter<CharSequence> staticAdapterHTK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.htk, android.R.layout.simple_spinner_item);
                        staticAdapterHTK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterHTK);
                        break;
                    case "Hungarian":
                        ArrayAdapter<CharSequence> staticAdapterHU = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hu, android.R.layout.simple_spinner_item);
                        staticAdapterHU.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterHU);
                        ArrayAdapter<CharSequence> staticAdapterHUK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.huk, android.R.layout.simple_spinner_item);
                        staticAdapterHUK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterHUK);
                        break;
                    case "Armenian":
                        ArrayAdapter<CharSequence> staticAdapterHY = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hy, android.R.layout.simple_spinner_item);
                        staticAdapterHY.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterHY);
                        ArrayAdapter<CharSequence> staticAdapterHYK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.hyk, android.R.layout.simple_spinner_item);
                        staticAdapterHYK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterHYK);
                        break;
                    case "Indonesian":
                        ArrayAdapter<CharSequence> staticAdapterID = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.id, android.R.layout.simple_spinner_item);
                        staticAdapterID.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterID);
                        ArrayAdapter<CharSequence> staticAdapterIDK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.idk, android.R.layout.simple_spinner_item);
                        staticAdapterIDK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterIDK);
                        break;
                    case "Icelandic":
                        ArrayAdapter<CharSequence> staticAdapterIS = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.is, android.R.layout.simple_spinner_item);
                        staticAdapterIS.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterIS);
                        ArrayAdapter<CharSequence> staticAdapterISK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.isk, android.R.layout.simple_spinner_item);
                        staticAdapterISK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterISK);
                        break;
                    case "Italian":
                        ArrayAdapter<CharSequence> staticAdapterIT = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.it, android.R.layout.simple_spinner_item);
                        staticAdapterIT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterIT);
                        ArrayAdapter<CharSequence> staticAdapterITK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.itk, android.R.layout.simple_spinner_item);
                        staticAdapterITK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterITK);
                        break;
                    case "Hebrew":
                        ArrayAdapter<CharSequence> staticAdapterIW = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.iw, android.R.layout.simple_spinner_item);
                        staticAdapterIW.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterIW);
                        ArrayAdapter<CharSequence> staticAdapterIWK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.iwk, android.R.layout.simple_spinner_item);
                        staticAdapterIWK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterIWK);
                        break;
                    case "Japanese":
                        ArrayAdapter<CharSequence> staticAdapterJA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ja, android.R.layout.simple_spinner_item);
                        staticAdapterJA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterJA);
                        ArrayAdapter<CharSequence> staticAdapterJAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.jak, android.R.layout.simple_spinner_item);
                        staticAdapterJAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterJAK);
                        break;
                    case "Georgian":
                        ArrayAdapter<CharSequence> staticAdapterKA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ka, android.R.layout.simple_spinner_item);
                        staticAdapterKA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterKA);
                        ArrayAdapter<CharSequence> staticAdapterKAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.kak, android.R.layout.simple_spinner_item);
                        staticAdapterKAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterKAK);
                        break;
                    case "Korean":
                        ArrayAdapter<CharSequence> staticAdapterKO = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ko, android.R.layout.simple_spinner_item);
                        staticAdapterKO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterKO);
                        ArrayAdapter<CharSequence> staticAdapterKOK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.kok, android.R.layout.simple_spinner_item);
                        staticAdapterKOK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterKOK);
                        break;
                    case "Latin":
                        ArrayAdapter<CharSequence> staticAdapterLA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.la, android.R.layout.simple_spinner_item);
                        staticAdapterLA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterLA);
                        ArrayAdapter<CharSequence> staticAdapterLAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lak, android.R.layout.simple_spinner_item);
                        staticAdapterLAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterLAK);
                        break;
                    case "Lao":
                        ArrayAdapter<CharSequence> staticAdapterLO = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lo, android.R.layout.simple_spinner_item);
                        staticAdapterLO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterLO);
                        ArrayAdapter<CharSequence> staticAdapterLOK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lok, android.R.layout.simple_spinner_item);
                        staticAdapterLOK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterLOK);
                        break;
                    case "Lithuanian":
                        ArrayAdapter<CharSequence> staticAdapterLT = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lt, android.R.layout.simple_spinner_item);
                        staticAdapterLT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterLT);
                        ArrayAdapter<CharSequence> staticAdapterLTK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ltk, android.R.layout.simple_spinner_item);
                        staticAdapterLTK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterLTK);
                        break;
                    case "Latvian":
                        ArrayAdapter<CharSequence> staticAdapterLV = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lv, android.R.layout.simple_spinner_item);
                        staticAdapterLV.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterLV);
                        ArrayAdapter<CharSequence> staticAdapterLVK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.lvk, android.R.layout.simple_spinner_item);
                        staticAdapterLVK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterLVK);
                        break;
                    case "Macedonian":
                        ArrayAdapter<CharSequence> staticAdapterMK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.mk, android.R.layout.simple_spinner_item);
                        staticAdapterMK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterMK);
                        ArrayAdapter<CharSequence> staticAdapterMKK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.mkk, android.R.layout.simple_spinner_item);
                        staticAdapterMKK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterMKK);
                        break;
                    case "Malay":
                        ArrayAdapter<CharSequence> staticAdapterMS = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ms, android.R.layout.simple_spinner_item);
                        staticAdapterMS.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterMS);
                        ArrayAdapter<CharSequence> staticAdapterMSK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.msk, android.R.layout.simple_spinner_item);
                        staticAdapterMSK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterMSK);
                        break;
                    case "Maltese":
                        ArrayAdapter<CharSequence> staticAdapterMT = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.mt, android.R.layout.simple_spinner_item);
                        staticAdapterMT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterMT);
                        ArrayAdapter<CharSequence> staticAdapterMTK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.mtk, android.R.layout.simple_spinner_item);
                        staticAdapterMTK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterMTK);
                        break;
                    case "Dutch":
                        ArrayAdapter<CharSequence> staticAdapterNL = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.nl, android.R.layout.simple_spinner_item);
                        staticAdapterNL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterNL);
                        ArrayAdapter<CharSequence> staticAdapterNLK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.nlk, android.R.layout.simple_spinner_item);
                        staticAdapterNLK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterNLK);
                        break;
                    case "Norwegian":
                        ArrayAdapter<CharSequence> staticAdapterNO = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.no, android.R.layout.simple_spinner_item);
                        staticAdapterNO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterNO);
                        ArrayAdapter<CharSequence> staticAdapterNOK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.nok, android.R.layout.simple_spinner_item);
                        staticAdapterNOK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterNOK);
                        break;
                    case "Polish":
                        ArrayAdapter<CharSequence> staticAdapterPL = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.pl, android.R.layout.simple_spinner_item);
                        staticAdapterPL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterPL);
                        ArrayAdapter<CharSequence> staticAdapterPLK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.plk, android.R.layout.simple_spinner_item);
                        staticAdapterPLK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterPLK);
                        break;
                    case "Portuguese":
                        ArrayAdapter<CharSequence> staticAdapterPT = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.pt, android.R.layout.simple_spinner_item);
                        staticAdapterPT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterPT);
                        ArrayAdapter<CharSequence> staticAdapterPTK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ptk, android.R.layout.simple_spinner_item);
                        staticAdapterPTK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterPTK);
                        break;
                    case "Romanian":
                        ArrayAdapter<CharSequence> staticAdapterRO = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ro, android.R.layout.simple_spinner_item);
                        staticAdapterRO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterRO);
                        ArrayAdapter<CharSequence> staticAdapterROK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.rok, android.R.layout.simple_spinner_item);
                        staticAdapterROK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterROK);
                        break;
                    case "Russian":
                        ArrayAdapter<CharSequence> staticAdapterRU = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ru, android.R.layout.simple_spinner_item);
                        staticAdapterRU.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterRU);
                        ArrayAdapter<CharSequence> staticAdapterRUK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ruk, android.R.layout.simple_spinner_item);
                        staticAdapterRUK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterRUK);
                        break;
                    case "Slovak":
                        ArrayAdapter<CharSequence> staticAdapterSK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sk, android.R.layout.simple_spinner_item);
                        staticAdapterSK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSK);
                        ArrayAdapter<CharSequence> staticAdapterSKK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.skk, android.R.layout.simple_spinner_item);
                        staticAdapterSKK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSKK);
                        break;
                    case "Slovenian":
                        ArrayAdapter<CharSequence> staticAdapterSL = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sl, android.R.layout.simple_spinner_item);
                        staticAdapterSL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSL);
                        ArrayAdapter<CharSequence> staticAdapterSLK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.slk, android.R.layout.simple_spinner_item);
                        staticAdapterSLK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSLK);
                        break;
                    case "Albanian":
                        ArrayAdapter<CharSequence> staticAdapterSQ = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sq, android.R.layout.simple_spinner_item);
                        staticAdapterSQ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSQ);
                        ArrayAdapter<CharSequence> staticAdapterSQK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sqk, android.R.layout.simple_spinner_item);
                        staticAdapterSQK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSQK);
                        break;
                    case "Serbian":
                        ArrayAdapter<CharSequence> staticAdapterSR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sr, android.R.layout.simple_spinner_item);
                        staticAdapterSR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSR);
                        ArrayAdapter<CharSequence> staticAdapterSRK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.srk, android.R.layout.simple_spinner_item);
                        staticAdapterSRK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSRK);
                        break;
                    case "Swedish":
                        ArrayAdapter<CharSequence> staticAdapterSV = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sv, android.R.layout.simple_spinner_item);
                        staticAdapterSV.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSV);
                        ArrayAdapter<CharSequence> staticAdapterSVK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.svk, android.R.layout.simple_spinner_item);
                        staticAdapterSVK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSVK);
                        break;
                    case "Swahili":
                        ArrayAdapter<CharSequence> staticAdapterSW = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.sw, android.R.layout.simple_spinner_item);
                        staticAdapterSW.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterSW);
                        ArrayAdapter<CharSequence> staticAdapterSWK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.swk, android.R.layout.simple_spinner_item);
                        staticAdapterSWK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterSWK);
                        break;
                    case "Tamil":
                        ArrayAdapter<CharSequence> staticAdapterTA = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ta, android.R.layout.simple_spinner_item);
                        staticAdapterTA.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterTA);
                        ArrayAdapter<CharSequence> staticAdapterTAK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.tak, android.R.layout.simple_spinner_item);
                        staticAdapterTAK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterTAK);
                        break;
                    case "Telugu":
                        ArrayAdapter<CharSequence> staticAdapterTE = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.te, android.R.layout.simple_spinner_item);
                        staticAdapterTE.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterTE);
                        ArrayAdapter<CharSequence> staticAdapterTEK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.tek, android.R.layout.simple_spinner_item);
                        staticAdapterTEK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterTEK);
                        break;
                    case "Thai":
                        ArrayAdapter<CharSequence> staticAdapterTH = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.th, android.R.layout.simple_spinner_item);
                        staticAdapterTH.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterTH);
                        ArrayAdapter<CharSequence> staticAdapterTHK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.thk, android.R.layout.simple_spinner_item);
                        staticAdapterTHK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterTHK);
                        break;
                    case "Filipino":
                        ArrayAdapter<CharSequence> staticAdapterTL = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.tl, android.R.layout.simple_spinner_item);
                        staticAdapterTL.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterTL);
                        ArrayAdapter<CharSequence> staticAdapterTLK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.tlk, android.R.layout.simple_spinner_item);
                        staticAdapterTLK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterTLK);
                        break;
                    case "Turkish":
                        ArrayAdapter<CharSequence> staticAdapterTR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.tr, android.R.layout.simple_spinner_item);
                        staticAdapterTR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterTR);
                        ArrayAdapter<CharSequence> staticAdapterTRK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.trk, android.R.layout.simple_spinner_item);
                        staticAdapterTRK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterTRK);
                        break;
                    case "Ukrainian":
                        ArrayAdapter<CharSequence> staticAdapterUK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.uk, android.R.layout.simple_spinner_item);
                        staticAdapterUK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterUK);
                        ArrayAdapter<CharSequence> staticAdapterUKK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ukk, android.R.layout.simple_spinner_item);
                        staticAdapterUKK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterUKK);
                        break;
                    case "Urdu":
                        ArrayAdapter<CharSequence> staticAdapterUR = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.ur, android.R.layout.simple_spinner_item);
                        staticAdapterUR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterUR);
                        ArrayAdapter<CharSequence> staticAdapterURK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.urk, android.R.layout.simple_spinner_item);
                        staticAdapterURK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterURK);
                        break;
                    case "Vietnamese":
                        ArrayAdapter<CharSequence> staticAdapterVI = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.vi, android.R.layout.simple_spinner_item);
                        staticAdapterVI.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterVI);
                        ArrayAdapter<CharSequence> staticAdapterVIK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.vik, android.R.layout.simple_spinner_item);
                        staticAdapterVIK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterVIK);
                        break;
                    case "Yiddish":
                        ArrayAdapter<CharSequence> staticAdapterYI = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.yi, android.R.layout.simple_spinner_item);
                        staticAdapterYI.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterYI);
                        ArrayAdapter<CharSequence> staticAdapterYIK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.yik, android.R.layout.simple_spinner_item);
                        staticAdapterYIK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterYIK);
                        break;
                    case "Chinese":
                        ArrayAdapter<CharSequence> staticAdapterZH = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.zh, android.R.layout.simple_spinner_item);
                        staticAdapterZH.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner2.setAdapter(staticAdapterZH);
                        ArrayAdapter<CharSequence> staticAdapterZHK = ArrayAdapter.createFromResource
                                (getBaseContext(), R.array.zhk, android.R.layout.simple_spinner_item);
                        staticAdapterZHK.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner3.setAdapter(staticAdapterZHK);
                        break;
                }
                if(checked2 == true){
                    staticSpinner2.setSelection (defaultValue2);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });

        assert staticSpinner2 != null;
        staticSpinner2.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
            @Override
            public void onItemSelected (AdapterView<?> parent, View view, int position, long id) {
                spinnerLang2 = parent.getItemAtPosition (position).toString ();
            }

            @Override
            public void onNothingSelected (AdapterView<?> parent) {
                spinnerLang2 = "";
            }
        });

        //keywords spinner
        final Spinner staticSpinner4 = (Spinner) findViewById (R.id.spinner4);

        staticSpinner2.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
            @Override
            public void onItemSelected (AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                spinnerLanguage = staticSpinner2.getSelectedItem ().toString ();

                switch (spinnerLanguage) {
                    case "Language 2":
                        ArrayAdapter<CharSequence> staticAdapterDEF = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.enk, android.R.layout.simple_spinner_item);
                        staticAdapterDEF.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterDEF);
                        break;
                    case "Afrikaans":
                        ArrayAdapter<CharSequence> staticAdapterAFK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.afk, android.R.layout.simple_spinner_item);
                        staticAdapterAFK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterAFK);
                        break;
                    case "Arabic":
                        ArrayAdapter<CharSequence> staticAdapterARK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.ark, android.R.layout.simple_spinner_item);
                        staticAdapterARK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterARK);
                        break;
                    case "Azerbaijani":
                        ArrayAdapter<CharSequence> staticAdapterAZK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.azk, android.R.layout.simple_spinner_item);
                        staticAdapterAZK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterAZK);
                        break;
                    case "Belarusian":
                        ArrayAdapter<CharSequence> staticAdapterBEK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.bek, android.R.layout.simple_spinner_item);
                        staticAdapterBEK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterBEK);
                        break;
                    case "Bulgarian":
                        ArrayAdapter<CharSequence> staticAdapterBGK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.bgk, android.R.layout.simple_spinner_item);
                        staticAdapterBGK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterBGK);
                        break;
                    case "Bengali":
                        ArrayAdapter<CharSequence> staticAdapterBNK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.bnk, android.R.layout.simple_spinner_item);
                        staticAdapterBNK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterBNK);
                        break;
                    case "Catalan":
                        ArrayAdapter<CharSequence> staticAdapterCAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.cak, android.R.layout.simple_spinner_item);
                        staticAdapterCAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterCAK);
                        break;
                    case "Czech":
                        ArrayAdapter<CharSequence> staticAdapterCSK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.csk, android.R.layout.simple_spinner_item);
                        staticAdapterCSK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterCSK);
                        break;
                    case "Welsh":
                        ArrayAdapter<CharSequence> staticAdapterCYK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.cyk, android.R.layout.simple_spinner_item);
                        staticAdapterCYK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterCYK);
                        break;
                    case "Danish":
                        ArrayAdapter<CharSequence> staticAdapterDAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.dak, android.R.layout.simple_spinner_item);
                        staticAdapterDAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterDAK);
                        break;
                    case "German":
                        ArrayAdapter<CharSequence> staticAdapterDEK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.dek, android.R.layout.simple_spinner_item);
                        staticAdapterDEK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterDEK);
                        break;
                    case "Greek":
                        ArrayAdapter<CharSequence> staticAdapterELK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.elk, android.R.layout.simple_spinner_item);
                        staticAdapterELK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterELK);
                        break;
                    case "English":
                        ArrayAdapter<CharSequence> staticAdapterENK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.enk, android.R.layout.simple_spinner_item);
                        staticAdapterENK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterENK);
                        break;
                    case "Esperanto":
                        ArrayAdapter<CharSequence> staticAdapterEOK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.eok, android.R.layout.simple_spinner_item);
                        staticAdapterEOK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterEOK);
                        break;
                    case "Spanish":
                        ArrayAdapter<CharSequence> staticAdapterESK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.esk, android.R.layout.simple_spinner_item);
                        staticAdapterESK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterESK);
                        break;
                    case "Estonian":
                        ArrayAdapter<CharSequence> staticAdapterETK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.etk, android.R.layout.simple_spinner_item);
                        staticAdapterETK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterETK);
                        break;
                    case "Basque":
                        ArrayAdapter<CharSequence> staticAdapterEUK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.euk, android.R.layout.simple_spinner_item);
                        staticAdapterEUK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterEUK);
                        break;
                    case "Persian":
                        ArrayAdapter<CharSequence> staticAdapterFAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.fak, android.R.layout.simple_spinner_item);
                        staticAdapterFAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterFAK);
                        break;
                    case "Finnish":
                        ArrayAdapter<CharSequence> staticAdapterFIK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.fik, android.R.layout.simple_spinner_item);
                        staticAdapterFIK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterFIK);
                        break;
                    case "French":
                        ArrayAdapter<CharSequence> staticAdapterFRK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.frk, android.R.layout.simple_spinner_item);
                        staticAdapterFRK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterFRK);
                        break;
                    case "Irish":
                        ArrayAdapter<CharSequence> staticAdapterGAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.gak, android.R.layout.simple_spinner_item);
                        staticAdapterGAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterGAK);
                        break;
                    case "Galician":
                        ArrayAdapter<CharSequence> staticAdapterGLK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.glk, android.R.layout.simple_spinner_item);
                        staticAdapterGLK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterGLK);
                        break;
                    case "Hindi":
                        ArrayAdapter<CharSequence> staticAdapterHIK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.hik, android.R.layout.simple_spinner_item);
                        staticAdapterHIK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterHIK);
                        break;
                    case "Croatian":
                        ArrayAdapter<CharSequence> staticAdapterHRK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.hrk, android.R.layout.simple_spinner_item);
                        staticAdapterHRK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterHRK);
                        break;
                    case "Haitian Creole":
                        ArrayAdapter<CharSequence> staticAdapterHTK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.htk, android.R.layout.simple_spinner_item);
                        staticAdapterHTK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterHTK);
                        break;
                    case "Hungarian":
                        ArrayAdapter<CharSequence> staticAdapterHUK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.huk, android.R.layout.simple_spinner_item);
                        staticAdapterHUK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterHUK);
                        break;
                    case "Armenian":
                        ArrayAdapter<CharSequence> staticAdapterHYK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.hyk, android.R.layout.simple_spinner_item);
                        staticAdapterHYK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterHYK);
                        break;
                    case "Indonesian":
                        ArrayAdapter<CharSequence> staticAdapterIDK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.idk, android.R.layout.simple_spinner_item);
                        staticAdapterIDK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterIDK);
                        break;
                    case "Icelandic":
                        ArrayAdapter<CharSequence> staticAdapterISK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.isk, android.R.layout.simple_spinner_item);
                        staticAdapterISK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterISK);
                        break;
                    case "Italian":
                        ArrayAdapter<CharSequence> staticAdapterITK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.itk, android.R.layout.simple_spinner_item);
                        staticAdapterITK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterITK);
                        break;
                    case "Hebrew":
                        ArrayAdapter<CharSequence> staticAdapterIWK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.iwk, android.R.layout.simple_spinner_item);
                        staticAdapterIWK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterIWK);
                        break;
                    case "Japanese":
                        ArrayAdapter<CharSequence> staticAdapterJAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.jak, android.R.layout.simple_spinner_item);
                        staticAdapterJAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterJAK);
                        break;
                    case "Georgian":
                        ArrayAdapter<CharSequence> staticAdapterKAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.kak, android.R.layout.simple_spinner_item);
                        staticAdapterKAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterKAK);
                        break;
                    case "Korean":
                        ArrayAdapter<CharSequence> staticAdapterKOK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.kok, android.R.layout.simple_spinner_item);
                        staticAdapterKOK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterKOK);
                        break;
                    case "Latin":
                        ArrayAdapter<CharSequence> staticAdapterLAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.lak, android.R.layout.simple_spinner_item);
                        staticAdapterLAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterLAK);
                        break;
                    case "Lao":
                        ArrayAdapter<CharSequence> staticAdapterLOK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.lok, android.R.layout.simple_spinner_item);
                        staticAdapterLOK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterLOK);
                        break;
                    case "Lithuanian":
                        ArrayAdapter<CharSequence> staticAdapterLTK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.ltk, android.R.layout.simple_spinner_item);
                        staticAdapterLTK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterLTK);
                        break;
                    case "Latvian":
                        ArrayAdapter<CharSequence> staticAdapterLVK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.lvk, android.R.layout.simple_spinner_item);
                        staticAdapterLVK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterLVK);
                        break;
                    case "Macedonian":
                        ArrayAdapter<CharSequence> staticAdapterMKK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.mkk, android.R.layout.simple_spinner_item);
                        staticAdapterMKK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterMKK);
                        break;
                    case "Malay":
                        ArrayAdapter<CharSequence> staticAdapterMSK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.msk, android.R.layout.simple_spinner_item);
                        staticAdapterMSK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterMSK);
                        break;
                    case "Maltese":
                        ArrayAdapter<CharSequence> staticAdapterMTK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.mtk, android.R.layout.simple_spinner_item);
                        staticAdapterMTK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterMTK);
                        break;
                    case "Dutch":
                        ArrayAdapter<CharSequence> staticAdapterNLK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.nlk, android.R.layout.simple_spinner_item);
                        staticAdapterNLK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterNLK);
                        break;
                    case "Norwegian":
                        ArrayAdapter<CharSequence> staticAdapterNOK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.nok, android.R.layout.simple_spinner_item);
                        staticAdapterNOK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterNOK);
                        break;
                    case "Polish":
                        ArrayAdapter<CharSequence> staticAdapterPLK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.plk, android.R.layout.simple_spinner_item);
                        staticAdapterPLK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterPLK);
                        break;
                    case "Portuguese":
                        ArrayAdapter<CharSequence> staticAdapterPTK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.ptk, android.R.layout.simple_spinner_item);
                        staticAdapterPTK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterPTK);
                        break;
                    case "Romanian":
                        ArrayAdapter<CharSequence> staticAdapterROK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.rok, android.R.layout.simple_spinner_item);
                        staticAdapterROK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterROK);
                        break;
                    case "Russian":
                        ArrayAdapter<CharSequence> staticAdapterRUK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.ruk, android.R.layout.simple_spinner_item);
                        staticAdapterRUK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterRUK);
                        break;
                    case "Slovak":
                        ArrayAdapter<CharSequence> staticAdapterSKK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.skk, android.R.layout.simple_spinner_item);
                        staticAdapterSKK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSKK);
                        break;
                    case "Slovenian":
                        ArrayAdapter<CharSequence> staticAdapterSLK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.slk, android.R.layout.simple_spinner_item);
                        staticAdapterSLK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSLK);
                        break;
                    case "Albanian":
                        ArrayAdapter<CharSequence> staticAdapterSQK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.sqk, android.R.layout.simple_spinner_item);
                        staticAdapterSQK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSQK);
                        break;
                    case "Serbian":
                        ArrayAdapter<CharSequence> staticAdapterSRK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.srk, android.R.layout.simple_spinner_item);
                        staticAdapterSRK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSRK);
                        break;
                    case "Swedish":
                        ArrayAdapter<CharSequence> staticAdapterSVK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.svk, android.R.layout.simple_spinner_item);
                        staticAdapterSVK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSVK);
                        break;
                    case "Swahili":
                        ArrayAdapter<CharSequence> staticAdapterSWK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.swk, android.R.layout.simple_spinner_item);
                        staticAdapterSWK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterSWK);
                        break;
                    case "Tamil":
                        ArrayAdapter<CharSequence> staticAdapterTAK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.tak, android.R.layout.simple_spinner_item);
                        staticAdapterTAK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterTAK);
                        break;
                    case "Telugu":
                        ArrayAdapter<CharSequence> staticAdapterTEK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.tek, android.R.layout.simple_spinner_item);
                        staticAdapterTEK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterTEK);
                        break;
                    case "Thai":
                        ArrayAdapter<CharSequence> staticAdapterTHK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.thk, android.R.layout.simple_spinner_item);
                        staticAdapterTHK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterTHK);
                        break;
                    case "Filipino":
                        ArrayAdapter<CharSequence> staticAdapterTLK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.tlk, android.R.layout.simple_spinner_item);
                        staticAdapterTLK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterTLK);
                        break;
                    case "Turkish":
                        ArrayAdapter<CharSequence> staticAdapterTRK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.trk, android.R.layout.simple_spinner_item);
                        staticAdapterTRK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterTRK);
                        break;
                    case "Ukrainian":
                        ArrayAdapter<CharSequence> staticAdapterUKK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.ukk, android.R.layout.simple_spinner_item);
                        staticAdapterUKK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterUKK);
                        break;
                    case "Urdu":
                        ArrayAdapter<CharSequence> staticAdapterURK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.urk, android.R.layout.simple_spinner_item);
                        staticAdapterURK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterURK);
                        break;
                    case "Vietnamese":
                        ArrayAdapter<CharSequence> staticAdapterVIK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.vik, android.R.layout.simple_spinner_item);
                        staticAdapterVIK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterVIK);
                        break;
                    case "Yiddish":
                        ArrayAdapter<CharSequence> staticAdapterYIK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.yik, android.R.layout.simple_spinner_item);
                        staticAdapterYIK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterYIK);
                        break;
                    case "Chinese":
                        ArrayAdapter<CharSequence> staticAdapterZHK = ArrayAdapter.createFromResource
                                (getBaseContext (), R.array.zhk, android.R.layout.simple_spinner_item);
                        staticAdapterZHK.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                        staticSpinner4.setAdapter (staticAdapterZHK);
                        break;
                }
            }

            @Override
            public void onNothingSelected (AdapterView<?> arg0) {

            }
        });

        assert staticSpinner3 != null;
        staticSpinner3.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
            @Override
            public void onItemSelected (AdapterView<?> parent, View view, int position, long id) {
                keywords = parent.getItemAtPosition (position).toString ();
                Pattern pattern = Pattern.compile("\\s");
                Matcher matcher = pattern.matcher(keywords);
                boolean found = matcher.find();

                if(keywords.equals ("Choose a Keyword Group")){
                    keywords = " ";
                }

                else if(found == true){
                   keywords = "\"" + keywords.replace(" ", "\" \"") + "\"";
                }
            }

            @Override
            public void onNothingSelected (AdapterView<?> parent) {

            }
        });

        assert staticSpinner4 != null;
        staticSpinner4.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
            @Override
            public void onItemSelected (AdapterView<?> parent, View view, int position, long id) {
                keywords2 = parent.getItemAtPosition (position).toString ();
                Pattern pattern = Pattern.compile ("\\s");
                Matcher matcher = pattern.matcher (keywords2);
                boolean found = matcher.find ();

                if (keywords2.equals ("Choose a Keyword Group")) {
                    keywords2 = " ";
                }

                else if (found == true) {
                    keywords2 = "\"" + keywords2.replace (" ", "\" \"") + "\"";
                }
            }

            @Override
            public void onNothingSelected (AdapterView<?> parent) {

            }
        });

        //search in browser
        adSearchIn1 = (EditText) findViewById(R.id.editText1);
        adSearchIn2 = (EditText) findViewById(R.id.editText2);
        adSearchIn3 = (EditText) findViewById(R.id.editText3);
        adSearchIn4 = (EditText) findViewById(R.id.editText4);

        final Intent intentSearch = new Intent (this, SearchResults.class);

        final Button adsearch = (Button) findViewById(R.id.button2);
        adsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newadSearchIn1 = adSearchIn1.getText().toString();
                newadSearchIn2 = adSearchIn2.getText().toString();
                newadSearchIn3 = adSearchIn3.getText().toString();
                newadSearchIn4 = adSearchIn4.getText().toString();

                if(getTrimmedLength (adSearchIn3.getText ()) != 0){
                    Pattern pattern = Pattern.compile("\\s");
                    Matcher matcher = pattern.matcher(adSearchIn3.getText ());
                    boolean found = matcher.find();

                    if(found == true){
                        newadSearchIn3 = adSearchIn3.getText().toString().replace(" ", " OR ");
                    }
                }

                if(getTrimmedLength (adSearchIn4.getText ()) != 0){
                    Pattern pattern2 = Pattern.compile("\\s");
                    Matcher matcher2 = pattern2.matcher(adSearchIn4.getText ());
                    boolean found2 = matcher2.find();

                    if(found2 == true){
                        newadSearchIn4 = adSearchIn4.getText().toString().replace(" ", " -");
                    }
                }

                if(getTrimmedLength(adSearchIn1.getText()) == 0 && getTrimmedLength(adSearchIn2.getText()) == 0 &&
                        getTrimmedLength(adSearchIn3.getText()) == 0 && getTrimmedLength(adSearchIn4.getText()) == 0) {

                    Context context = getApplicationContext();
                    CharSequence text = "Please Type Some Words to Search";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                else{
                    if (getTrimmedLength(adSearchIn2.getText()) != 0) {
                        if (getTrimmedLength(adSearchIn4.getText()) != 0) {
                            String finSearchString = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "\""
                                    + adSearchIn2.getText() + "\"" + " " + "-" + newadSearchIn4 + " " + keywords + " " +
                                    keywords2;

                            userHistoryDB = openOrCreateDatabase("UserHisDB", MODE_PRIVATE, null);
                            userHistoryDB.execSQL("CREATE TABLE IF NOT EXISTS searchHistoryList " +
                                    "(id integer primary key," + " history VARCHAR, rating integer);");
                            userHistoryDB.execSQL("INSERT INTO searchHistoryList (history, rating) VALUES ('"+
                                    finSearchString +"', 0);");

//                            Uri uri = Uri.parse("http://www.google.com/#q=" + adSearchIn1.getText() + " " +
//                                    newadSearchIn3 + " " + "\"" + adSearchIn2.getText() + "\"" + " " + "-" +
//                                    newadSearchIn4 + keywords + "&hl=" + langCodesFirst (spinnerLanguage) + "&hl=" +
//                                    langCodes (spinnerLang2));
//
//                            Intent adsearchintent = new Intent(Intent.ACTION_VIEW, uri);
//                            startActivity(adsearchintent);

                            queryToSend = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "\"" +
                                    adSearchIn2.getText() + "\"" + " " + "-" + newadSearchIn4 + "&hl=" +
                                    langCodesFirst (spinnerLanguage) + "&hl=" + langCodes (spinnerLang2);
                            intentSearch.putExtra("sending", queryToSend);
                            intentSearch.putExtra("keywords", keywords);
                            intentSearch.putExtra("keywords2", keywords2);
                            startActivityForResult (intentSearch, SEARCH_REQUEST);
                        }
                        else {
                            String finSearchString = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "\""
                                    + adSearchIn2.getText() + " " + keywords + " " + keywords2;

                            userHistoryDB = openOrCreateDatabase("UserHisDB", MODE_PRIVATE, null);
                            userHistoryDB.execSQL("CREATE TABLE IF NOT EXISTS searchHistoryList " +
                                    "(id integer primary key," + " history VARCHAR, rating integer);");
                            userHistoryDB.execSQL("INSERT INTO searchHistoryList (history, rating) VALUES ('"+
                                    finSearchString +"', 0);");

//                            Uri uri = Uri.parse("http://www.google.com/#q=" + adSearchIn1.getText() + " " +
//                                    newadSearchIn3 + " " + "\"" + adSearchIn2.getText() + "&hl=" +
//                                    langCodesFirst (spinnerLanguage) + keywords + "&hl=" + langCodes (spinnerLang2));
//
//                            Intent adsearchintent = new Intent(Intent.ACTION_VIEW, uri);
//                            startActivity(adsearchintent);

                            queryToSend = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "\"" +
                                    adSearchIn2.getText() + "&hl=" + langCodesFirst (spinnerLanguage) + "&hl=" +
                                    langCodes (spinnerLang2);
                            intentSearch.putExtra("sending", queryToSend);
                            intentSearch.putExtra("keywords", keywords);
                            intentSearch.putExtra("keywords2", keywords2);
                            startActivityForResult (intentSearch, SEARCH_REQUEST);
                        }
                    }
                    else {
                        if (getTrimmedLength(adSearchIn4.getText()) != 0) {
                            String finSearchString = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "-"
                                    + newadSearchIn4 + " " + keywords + " " + keywords2;

                            userHistoryDB = openOrCreateDatabase("UserHisDB", MODE_PRIVATE, null);
                            userHistoryDB.execSQL("CREATE TABLE IF NOT EXISTS searchHistoryList " +
                                    "(id integer primary key," + " history VARCHAR, rating integer);");
                            userHistoryDB.execSQL("INSERT INTO searchHistoryList (history, rating) VALUES ('"+
                                    finSearchString +"', 0);");

//                            Uri uri = Uri.parse("http://www.google.com/#q=" + adSearchIn1.getText() + " " +
//                                    newadSearchIn3 + " " + "-" + newadSearchIn4 + keywords + "&hl=" +
//                                    langCodesFirst (spinnerLanguage) + "&hl=" + langCodes (spinnerLang2));
//
//                            Intent adsearchintent = new Intent(Intent.ACTION_VIEW, uri);
//                            startActivity(adsearchintent);

                            queryToSend = adSearchIn1.getText() + " " + newadSearchIn3 + " " + "-" +
                                    newadSearchIn4 + "&hl=" + langCodesFirst (spinnerLanguage) + "&hl=" +
                                    langCodes (spinnerLang2);
                            intentSearch.putExtra("sending", queryToSend);
                            intentSearch.putExtra("keywords", keywords);
                            intentSearch.putExtra("keywords2", keywords2);
                            startActivityForResult (intentSearch, SEARCH_REQUEST);
                        }
                        else {
                            String finSearchString = adSearchIn1.getText() + " " + newadSearchIn3 + " " + keywords + " " + keywords2;

                            userHistoryDB = openOrCreateDatabase("UserHisDB", MODE_PRIVATE, null);
                            userHistoryDB.execSQL("CREATE TABLE IF NOT EXISTS searchHistoryList " +
                                    "(id integer primary key," + " history VARCHAR, rating integer);");
                            userHistoryDB.execSQL("INSERT INTO searchHistoryList (history, rating) VALUES ('"+
                                    finSearchString +"', 0);");

//                            Uri uri = Uri.parse("http://www.google.com/#q=" + adSearchIn1.getText() + " " +
//                                    newadSearchIn3 + keywords + "&hl=" + langCodesFirst (spinnerLanguage) + "&hl=" +
//                                    langCodes (spinnerLang2));
//
//                            Intent adsearchintent = new Intent(Intent.ACTION_VIEW, uri);
//                            startActivity(adsearchintent);

                            queryToSend = adSearchIn1.getText() + " " + newadSearchIn3 + "&hl=" +
                                    langCodesFirst (spinnerLanguage) + "&hl=" + langCodes (spinnerLang2);
                            intentSearch.putExtra("sending", queryToSend);
                            intentSearch.putExtra("keywords", keywords);
                            intentSearch.putExtra("keywords2", keywords2);
                            startActivityForResult (intentSearch, SEARCH_REQUEST);
                        }
                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public String langCodesFirst (String fromSpinner) {
        String firstValue = null;
        switch (fromSpinner) {
            case "Afrikaans":
                firstValue = "AF";
                break;
            case "Arabic":
                firstValue = "AR";
                break;
            case "Azerbaijani":
                firstValue = "AZ";
                break;
            case "Belarusian":
                firstValue = "BE";
                break;
            case "Bulgarian":
                firstValue = "BG";
                break;
            case "Bengali":
                firstValue = "BN";
                break;
            case "Catalan":
                firstValue = "CA";
                break;
            case "Czech":
                firstValue = "CS";
                break;
            case "Welsh":
                firstValue = "CY";
                break;
            case "Danish":
                firstValue = "DA";
                break;
            case "German":
                firstValue = "DE";
                break;
            case "Greek":
                firstValue = "EL";
                break;
            case "English":
                firstValue = "EN";
                break;
            case "Esperanto":
                firstValue = "EO";
                break;
            case "Spanish":
                firstValue = "ES";
                break;
            case "Estonian":
                firstValue = "ET";
                break;
            case "Basque":
                firstValue = "EU";
                break;
            case "Persian":
                firstValue = "FA";
                break;
            case "Finnish":
                firstValue = "FI";
                break;
            case "French":
                firstValue = "FR";
                break;
            case "Irish":
                firstValue = "GA";
                break;
            case "Galician":
                firstValue = "GL";
                break;
            case "Hindi":
                firstValue = "HI";
                break;
            case "Croatian":
                firstValue = "HR";
                break;
            case "Haitian Creole":
                firstValue = "HT";
                break;
            case "Hungarian":
                firstValue = "HU";
                break;
            case "Armenian":
                firstValue = "HY";
                break;
            case "Indonesian":
                firstValue = "ID";
                break;
            case "Icelandic":
                firstValue = "IS";
                break;
            case "Italian":
                firstValue = "IT";
                break;
            case "Hebrew":
                firstValue = "IW";
                break;
            case "Japanese":
                firstValue = "JA";
                break;
            case "Georgian":
                firstValue = "KA";
                break;
            case "Korean":
                firstValue = "KO";
                break;
            case "Latin":
                firstValue = "LA";
                break;
            case "Lao":
                firstValue = "LO";
                break;
            case "Lithuanian":
                firstValue = "LT";
                break;
            case "Latvian":
                firstValue = "LV";
                break;
            case "Macedonian":
                firstValue = "MK";
                break;
            case "Malay":
                firstValue = "MS";
                break;
            case "Maltese":
                firstValue = "MT";
                break;
            case "Dutch":
                firstValue = "NL";
                break;
            case "Norwegian":
                firstValue = "NO";
                break;
            case "Polish":
                firstValue = "PL";
                break;
            case "Portuguese":
                firstValue = "PT";
                break;
            case "Romanian":
                firstValue = "RO";
                break;
            case "Russian":
                firstValue = "RU";
                break;
            case "Slovak":
                firstValue = "SK";
                break;
            case "Slovenian":
                firstValue = "SL";
                break;
            case "Albanian":
                firstValue = "SQ";
                break;
            case "Serbian":
                firstValue = "SR";
                break;
            case "Swedish":
                firstValue = "SV";
                break;
            case "Swahili":
                firstValue = "SW";
                break;
            case "Tamil":
                firstValue = "TA";
                break;
            case "Telugu":
                firstValue = "TE";
                break;
            case "Thai":
                firstValue = "TH";
                break;
            case "Filipino":
                firstValue = "TL";
                break;
            case "Turkish":
                firstValue = "TR";
                break;
            case "Ukrainian":
                firstValue = "UK";
                break;
            case "Urdu":
                firstValue = "UR";
                break;
            case "Vietnamese":
                firstValue = "VI";
                break;
            case "Yiddish":
                firstValue = "YI";
                break;
            case "Chinese":
                firstValue = "ZH";
                break;
        }
        return firstValue;
    }

    Hashing test1 = new Hashing ();

    public String langCodes(String selectedOnSpinnerTwoNoArrayList){
        String langCodesForSecondSpinner;

        langCodesForSecondSpinner = test1.hashMethodNoArrayList ().get(selectedOnSpinnerTwoNoArrayList);

        return langCodesForSecondSpinner;
    }
}
