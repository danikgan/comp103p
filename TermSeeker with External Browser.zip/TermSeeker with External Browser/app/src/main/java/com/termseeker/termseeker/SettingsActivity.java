package com.termseeker.termseeker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;

public class SettingsActivity extends AppCompatActivity {

    Switch mySwitch1, mySwitch2;
    public Boolean defLang1;
    public Boolean defLang2;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById (R.id.toolbar);
        setSupportActionBar (toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled (true);

        SharedPreferences pref1 = getApplicationContext().getSharedPreferences ("MyPref1", MODE_PRIVATE);
        SharedPreferences pref2 = getApplicationContext().getSharedPreferences ("MyPref2", MODE_PRIVATE);

        int defaultValue1 = pref1.getInt ("spinner1", 0);
        int defaultValue2 = pref2.getInt ("spinner2", 0);

        SharedPreferences pref3 = getApplicationContext().getSharedPreferences ("MyPref3", MODE_PRIVATE);
        SharedPreferences pref4 = getApplicationContext().getSharedPreferences ("MyPref4", MODE_PRIVATE);

        final boolean checked1 = pref3.getBoolean ("switch1", false);
        boolean checked2 = pref4.getBoolean ("switch2", false);

        final Spinner staticSpinner1 = (Spinner) findViewById (R.id.spinnerDef1);

        // Create an ArrayAdapter using the string array and a default spinner
        ArrayAdapter<CharSequence> staticAdapter1 = ArrayAdapter.createFromResource (this, R.array.deflang,
                android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        staticAdapter1.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        staticSpinner1.setAdapter (staticAdapter1);
        staticSpinner1.setSelection (defaultValue1);
        staticSpinner1.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener (){
            @Override
            public void onItemSelected (AdapterView<?> parent, View view, int position, long id) {
                if(checked1 == true){
                    SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref1", MODE_PRIVATE);
                    SharedPreferences.Editor editor = pref.edit ();

                    editor.putInt("spinner1", position);
                    editor.commit();
                }
            }

            @Override
            public void onNothingSelected (AdapterView<?> parent) {

            }
        });

//        // spinner 2
//        final Spinner staticSpinner2 = (Spinner) findViewById(R.id.spinnerDef2);
//        // Create an ArrayAdapter using the string array and a default spinner
//        ArrayAdapter<CharSequence> staticAdapter2 = ArrayAdapter.createFromResource(this, R.array.deflang,
//                        android.R.layout.simple_spinner_item);
//        // Specify the layout to use when the list of choices appears
//        staticAdapter2.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
//        // Apply the adapter to the spinner
//        staticSpinner2.setAdapter (staticAdapter2);
//        staticSpinner2.setSelection (defaultValue2);

        mySwitch1 = (Switch) findViewById (R.id.switch1);
        if(checked1 == true){
            mySwitch1.setChecked (true);
            staticSpinner1.setEnabled (true);
        }
        else{
            mySwitch1.setChecked (false);
            staticSpinner1.setEnabled (false);
        }

        mySwitch1.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener () {
            public void onCheckedChanged (CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    defLang1 = true;
                    SharedPreferences pref3 = getApplicationContext().getSharedPreferences("MyPref3", MODE_PRIVATE);
                    SharedPreferences.Editor editor = pref3.edit ();

                    editor.putBoolean ("switch1", true);
                    editor.commit();

                    // spinner 1
                    staticSpinner1.setEnabled (true);
                    staticSpinner1.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
                        @Override
                        public void onItemSelected (AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                            String spinnerLanguage1 = staticSpinner1.getSelectedItem ().toString ();

                            SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref1", MODE_PRIVATE);
                            SharedPreferences.Editor editor = pref.edit ();

                            editor.putInt("spinner1", arg2);
                            editor.commit();
                        }

                        @Override
                        public void onNothingSelected (AdapterView<?> arg0) {

                        }
                    });
                }
                else {
                    defLang1 = false;
                    // spinner 1
                    final Spinner staticSpinner1 = (Spinner) findViewById (R.id.spinnerDef1);
                    // Create an ArrayAdapter using the string array and a default spinner
                    ArrayAdapter<CharSequence> staticAdapter1 = ArrayAdapter.createFromResource
                            (SettingsActivity.this, R.array.deflang, android.R.layout.simple_spinner_item);
                    // Specify the layout to use when the list of choices appears
                    staticAdapter1.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
                    // Apply the adapter to the spinner
                    staticSpinner1.setAdapter (staticAdapter1);
                    staticSpinner1.setEnabled (false);
                    staticSpinner1.setSelection (0);

                    SharedPreferences pref3 = getApplicationContext().getSharedPreferences("MyPref3", MODE_PRIVATE);
                    SharedPreferences.Editor editor = pref3.edit ();

                    editor.putBoolean ("switch1", false);
                    editor.commit();
                }
            }
        });

//        mySwitch2 = (Switch) findViewById (R.id.switch2);
//        if(checked2 == true){
//            mySwitch2.setChecked (true);
//            staticSpinner2.setEnabled (true);
//        }
//        else{
//            mySwitch2.setChecked (false);
//            staticSpinner2.setEnabled (false);
//        }

//        mySwitch2.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener () {
//            public void onCheckedChanged (CompoundButton buttonView, boolean isChecked) {
//                if (isChecked == true) {
//                    defLang2 = true;
//                    SharedPreferences pref4 = getApplicationContext().getSharedPreferences("MyPref4", MODE_PRIVATE);
//                    SharedPreferences.Editor editor = pref4.edit ();
//
//                    editor.putBoolean ("switch2", true);
//                    editor.commit();
//
//                    // spinner 2
//                    staticSpinner2.setEnabled (true);
//                    staticSpinner2.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener () {
//                        @Override
//                        public void onItemSelected (AdapterView<?> arg0, View arg1, int arg2, long arg3) {
//                            String spinnerLanguage2 = staticSpinner2.getSelectedItem ().toString ();
//                            String translatedLangCode = langCodes (spinnerLanguage2);
//                            deflangMethod2 (translatedLangCode);
//
//                            SharedPreferences pref2 = getApplicationContext ().getSharedPreferences
//                                    ("MyPref2", MODE_PRIVATE);
//                            SharedPreferences.Editor editor = pref2.edit ();
//
//                            editor.putInt ("spinner2", arg2);
//                            editor.commit ();
//                        }
//
//                        @Override
//                        public void onNothingSelected (AdapterView<?> parent) {
//
//                        }
//                    });
//                }
//
//                else {
//                    defLang2 = false;
//
//                    // spinner 2
//                    final Spinner staticSpinner2 = (Spinner) findViewById (R.id.spinnerDef2);
//                    // Create an ArrayAdapter using the string array and a default spinner
//                    ArrayAdapter<CharSequence> staticAdapter2 = ArrayAdapter.createFromResource
//                            (SettingsActivity.this, R.array.deflang, android.R.layout.simple_spinner_item);
//                    // Specify the layout to use when the list of choices appears
//                    staticAdapter2.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
//                    // Apply the adapter to the spinner
//                    staticSpinner2.setAdapter (staticAdapter2);
//                    staticSpinner2.setEnabled (false);
//                    staticSpinner2.setSelection (0);
//
//                    SharedPreferences pref4 = getApplicationContext().getSharedPreferences("MyPref4", MODE_PRIVATE);
//                    SharedPreferences.Editor editor = pref4.edit ();
//
//                    editor.putBoolean ("switch2", false);
//                    editor.commit();
//                }
//            }
//        });
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    Hashing test1 = new Hashing ();

    public String langCodes(String selectedOnSpinnerTwoNoArrayList){
        String langCodesForSecondSpinner;

        langCodesForSecondSpinner = test1.hashMethodNoArrayList ().get(selectedOnSpinnerTwoNoArrayList);

        return langCodesForSecondSpinner;
    }

    DefLang2 test2 = new DefLang2 ();

    public String deflangMethod2 (String translatedLangCode){
        String defLangForDefSpinner;

        defLangForDefSpinner = test2.hashMethodDefLang2 ().get (translatedLangCode);

        return  defLangForDefSpinner;
    }
}
