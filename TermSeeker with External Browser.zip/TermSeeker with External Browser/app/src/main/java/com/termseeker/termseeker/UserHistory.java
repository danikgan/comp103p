package com.termseeker.termseeker;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.NavUtils;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UserHistory extends AppCompatActivity {

    SQLiteDatabase userHistoryDB = null;
    public ArrayList<String> sonArtik = new ArrayList<String>();
    public ArrayList<String> sonArtikRating = new ArrayList<String>();
    private static final int SEARCH_REQUEST = 1010;
    CharSequence queryToSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_history);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        userHistoryDB = this.openOrCreateDatabase("UserHisDB", MODE_PRIVATE, null);
        userHistoryDB.execSQL("CREATE TABLE IF NOT EXISTS searchHistoryList " + "(id integer primary key," +
                " history VARCHAR, rating integer);");

        Cursor cursor = userHistoryDB.rawQuery("SELECT * FROM searchHistoryList", null);
        int idColumn = cursor.getColumnIndex("id");
        int historyColumn = cursor.getColumnIndex("history");
        final int ratingColumn = cursor.getColumnIndex("rating");
        cursor.moveToLast();

        final ArrayList<String> fromUserHisDB = new ArrayList<String>();
        final ArrayList<String> fromUserHisDBRating = new ArrayList<String>();

        if(cursor != null && cursor.getCount() > 0){
            do{
                String id = cursor.getString(idColumn);
                String history = cursor.getString(historyColumn);
                String rating = cursor.getString(ratingColumn);
                fromUserHisDB.add(history);

                if(rating.equals("0")) {
                    fromUserHisDBRating.add(" ");
                }
                else{
                    fromUserHisDBRating.add(rating);
                }
            }
            while(cursor.moveToPrevious());
        }
        else{
            Toast.makeText(this, "This page displays all search inputs you have made. Right now, there are no searches " +
                    "saved.", Toast.LENGTH_SHORT).show();
        }

        for(int j = 0; j < fromUserHisDB.size(); j++){
            sonArtik.add(fromUserHisDB.get(j));
            sonArtikRating.add(fromUserHisDBRating.get(j));
        }

        final ListAdapter theAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fromUserHisDB);
        final ListAdapter theAdapterRating = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
                fromUserHisDBRating);

        final ListView listView = (ListView) findViewById(R.id.listView);
        listView.setAdapter(theAdapter);
        final ListView listViewRating = (ListView) findViewById(R.id.listViewRating);
        listViewRating.setAdapter(theAdapterRating);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final String dbye = fromUserHisDB.get(i);

                new AlertDialog.Builder(UserHistory.this)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setTitle("TermSeeker")
                        .setMessage("Are you sure you want to delete this search?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                userHistoryDB.delete("searchHistoryList", "history" + "=?", new String[]{dbye});
                                Intent userHistoryScreen = new Intent(getApplicationContext(), UserHistory.class);
                                startActivity(userHistoryScreen);
                            }

                        })
                        .setNegativeButton("No", null)
                        .show();
                return true;
            }
        });

        final Intent intent = new Intent (this, SearchResults.class);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String dbye2 = fromUserHisDB.get(position);

                Cursor c = userHistoryDB.rawQuery("SELECT history FROM searchHistoryList WHERE history = ? ",
                        new String[]{dbye2});
                c.moveToFirst();
                int historyColumnRating = c.getColumnIndex("history");
                String forSearch = c.getString(historyColumnRating);

                final Dialog rankDialog = new Dialog(UserHistory.this, R.style.FullHeightDialog);
                rankDialog.setContentView(R.layout.rank_dialog);
                rankDialog.setCancelable(true);
                final RatingBar ratingBar = (RatingBar) rankDialog.findViewById(R.id.dialog_ratingbar);
                ratingBar.setRating(0);

                final TextView text = (TextView) rankDialog.findViewById(R.id.rank_dialog_text1);
                text.setText(forSearch);

                Button rateButton = (Button) rankDialog.findViewById(R.id.rank_dialog_button);
                rateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor cur = userHistoryDB.rawQuery("SELECT rating FROM searchHistoryList WHERE history = ? ",
                                new String[]{dbye2});
                        cur.moveToFirst();
                        int ratingColumnRating = cur.getColumnIndex("rating");
                        String rate = cur.getString(ratingColumnRating);
                        int userRating = (int) ratingBar.getRating();
                        userHistoryDB.execSQL("UPDATE searchHistoryList SET rating = '"+ userRating +"' " +
                                "WHERE history = '"+ dbye2 +"' ");
                        Intent userHistoryS = new Intent(getApplicationContext(), UserHistory.class);
                        startActivity(userHistoryS);
                    }
                });

                Button searchAgainButton = (Button) rankDialog.findViewById(R.id.buttonSearchAgain);
                searchAgainButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor c = userHistoryDB.rawQuery("SELECT history FROM searchHistoryList WHERE history = ? ",
                                new String[]{dbye2});
                        c.moveToFirst();
                        int historyColumnRating = c.getColumnIndex("history");
                        String forSearch = c.getString(historyColumnRating);
                        userHistoryDB.execSQL("INSERT INTO searchHistoryList (history, rating) VALUES " +
                                "('" + forSearch + "', 0);");
//                        Uri uri = Uri.parse("http://www.google.com/#q=" + forSearch + "&lr=lang_" + "&lr=lang_");
//                        Intent userHistoryS = new Intent(getApplicationContext(), UserHistory.class);
//                        startActivity(userHistoryS);
//                        Intent intentUHSerach = new Intent(Intent.ACTION_VIEW, uri);
//                        startActivity(intentUHSerach);

                        queryToSend = forSearch + "&hl=" + "&hl";
                        intent.putExtra("sending", queryToSend);
//                        intent.putExtra("keywords", keywords);
//                        intent.putExtra("lan1", langCodesFirst (spinnerLanguage));
//                        intent.putExtra("lan2", langCodes (spinnerLang2));
                        startActivityForResult (intent, SEARCH_REQUEST);
                    }
                });
                rankDialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_user_history, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        EmailUH passEmail = new EmailUH();
        String sonEmail = passEmail.forUHEmail(sonArtik, sonArtikRating);

        if (id == R.id.action_delete_history) {
            new AlertDialog.Builder(this)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setTitle("TermSeeker")
                    .setMessage("Are you sure you want to delete user history?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            userHistoryDB.execSQL("DROP TABLE IF EXISTS searchHistoryList");
                            Intent userHistoryScreen = new Intent(getApplicationContext(), UserHistory.class);
                            startActivity(userHistoryScreen);
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
        }
        else if (id == R.id.action_send_email) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/plain");
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{""});
            i.putExtra(Intent.EXTRA_SUBJECT, "TermSeeker My User History");
            i.putExtra(Intent.EXTRA_TEXT, sonEmail);
            try {
                startActivity(Intent.createChooser(i, "Send User History"));
            }
            catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(UserHistory.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
            }
        }
        else if(id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask (this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        userHistoryDB.close();
        super.onDestroy();
    }

    public class EmailUH {
        public String forUHEmail(ArrayList<String> fromUserHisDB, ArrayList<String> fromUserHisDBRating) {
            String UserHistoryEmail = "";
            for (int i = 0; i < fromUserHisDB.size(); i++) {
                UserHistoryEmail += fromUserHisDB.get(i) + "(" + fromUserHisDBRating.get(i) + ")\n";
            }
            return UserHistoryEmail;
        }
    }

    public String langCodesFirst (String fromSpinner) {
        String firstValue = null;
        switch (fromSpinner) {
            case "Afrikaans":
                firstValue = "AF";
                break;
            case "Arabic":
                firstValue = "AR";
                break;
            case "Azerbaijani":
                firstValue = "AZ";
                break;
            case "Belarusian":
                firstValue = "BE";
                break;
            case "Bulgarian":
                firstValue = "BG";
                break;
            case "Bengali":
                firstValue = "BN";
                break;
            case "Catalan":
                firstValue = "CA";
                break;
            case "Czech":
                firstValue = "CS";
                break;
            case "Welsh":
                firstValue = "CY";
                break;
            case "Danish":
                firstValue = "DA";
                break;
            case "German":
                firstValue = "DE";
                break;
            case "Greek":
                firstValue = "EL";
                break;
            case "English":
                firstValue = "EN";
                break;
            case "Esperanto":
                firstValue = "EO";
                break;
            case "Spanish":
                firstValue = "ES";
                break;
            case "Estonian":
                firstValue = "ET";
                break;
            case "Basque":
                firstValue = "EU";
                break;
            case "Persian":
                firstValue = "FA";
                break;
            case "Finnish":
                firstValue = "FI";
                break;
            case "French":
                firstValue = "FR";
                break;
            case "Irish":
                firstValue = "GA";
                break;
            case "Galician":
                firstValue = "GL";
                break;
            case "Hindi":
                firstValue = "HI";
                break;
            case "Croatian":
                firstValue = "HR";
                break;
            case "Haitian Creole":
                firstValue = "HT";
                break;
            case "Hungarian":
                firstValue = "HU";
                break;
            case "Armenian":
                firstValue = "HY";
                break;
            case "Indonesian":
                firstValue = "ID";
                break;
            case "Icelandic":
                firstValue = "IS";
                break;
            case "Italian":
                firstValue = "IT";
                break;
            case "Hebrew":
                firstValue = "IW";
                break;
            case "Japanese":
                firstValue = "JA";
                break;
            case "Georgian":
                firstValue = "KA";
                break;
            case "Korean":
                firstValue = "KO";
                break;
            case "Latin":
                firstValue = "LA";
                break;
            case "Lao":
                firstValue = "LO";
                break;
            case "Lithuanian":
                firstValue = "LT";
                break;
            case "Latvian":
                firstValue = "LV";
                break;
            case "Macedonian":
                firstValue = "MK";
                break;
            case "Malay":
                firstValue = "MS";
                break;
            case "Maltese":
                firstValue = "MT";
                break;
            case "Dutch":
                firstValue = "NL";
                break;
            case "Norwegian":
                firstValue = "NO";
                break;
            case "Polish":
                firstValue = "PL";
                break;
            case "Portuguese":
                firstValue = "PT";
                break;
            case "Romanian":
                firstValue = "RO";
                break;
            case "Russian":
                firstValue = "RU";
                break;
            case "Slovak":
                firstValue = "SK";
                break;
            case "Slovenian":
                firstValue = "SL";
                break;
            case "Albanian":
                firstValue = "SQ";
                break;
            case "Serbian":
                firstValue = "SR";
                break;
            case "Swedish":
                firstValue = "SV";
                break;
            case "Swahili":
                firstValue = "SW";
                break;
            case "Tamil":
                firstValue = "TA";
                break;
            case "Telugu":
                firstValue = "TE";
                break;
            case "Thai":
                firstValue = "TH";
                break;
            case "Filipino":
                firstValue = "TL";
                break;
            case "Turkish":
                firstValue = "TR";
                break;
            case "Ukrainian":
                firstValue = "UK";
                break;
            case "Urdu":
                firstValue = "UR";
                break;
            case "Vietnamese":
                firstValue = "VI";
                break;
            case "Yiddish":
                firstValue = "YI";
                break;
            case "Chinese":
                firstValue = "ZH";
                break;
        }
        return firstValue;
    }

    Hashing test1 = new Hashing ();

    public String langCodes (String selectedOnSpinnerTwoNoArrayList) {
        String langCodesForSecondSpinner;

        langCodesForSecondSpinner = test1.hashMethodNoArrayList ().get (selectedOnSpinnerTwoNoArrayList);

        return langCodesForSecondSpinner;
    }
}
